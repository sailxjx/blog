<?php
class VerifyPic {
    
    protected $image;
    protected $width;
    protected $height;
    protected $backimg;
    protected $fonts = array(
        'STXINGKA.TTF'
    );
    protected $verify;
    protected $sourcedir;
    
    public function __construct($width, $height) {
        $this->sourcedir = './source/';
        $image = imagecreatetruecolor($width, $height);
        $backimg = imagecreatefrompng($this->sourcedir . '4.png');
        imagecopy($image, $backimg, 0, 0, 0, 0, $width, $height);
        $this->width = $width;
        $this->height = $height;
        $this->image = $image;
        $this->backimg = $backimg;
    }
    
    public function genCode($n = 4) {
        $dict = 'ABCDEFGHIJKLNMPQRSTUVWXYZ123456789';
        $dictlen = strlen($dict);
        $image = $this->image;
        $verify = '';
        $fontfile = $this->sourcedir . $this->fonts[0];
        $colors = array(
            imagecolorallocate($image, 255, 0, 0) , //红
            imagecolorallocate($image, 0, 0, 255) , //蓝
            imagecolorallocate($image, 0, 0, 0) , //黑
        );
        for ($i = 0;$i < $n;$i++) {
            $verify.= $code = substr($dict, mt_rand(0, $dictlen - 1) , 1);
            imagettftext($image, 20, mt_rand(-15, 15) , ($i * 15) + 3, mt_rand(20, 25) , $colors[array_rand($colors) ], $fontfile, $code);
        }
        return $this;
    }
    
    public function genHanzi($n = 2) {
        $dict = "的一是在了不和有大这主中人上为们地个用工时要动国产以我到他会作来分生对于学下级就年阶义发成部民可出能方进同行面说种过命度革而多子后自社加小机也经力线本电高量长党得实家定深法表着水理化争现所二起政三好十战无农使性前等反体合斗路图把结第里正新开论之物从当两些还天资事队批如应形想制心样干都向变关点育重其思与间内去因件日利相由压员气业代全组数果期导平各基或月毛然问比展那它最及外没看治提五解系林者米群头意只明四道马认次文通但条较克又公孔领军流入接席位情运器并飞原油放立题质指建区验活众很教决特此常石强极土少已根共直团统式转别造切九你取西持总料连任志观调七么山程百报更见必真保热委手改管处己将修支识病象几先老光专什六型具示复安带每东增则完风回南广劳轮科北打积车计给节做务被整联步类集号列温装即毫知轴研单色坚据速防史拉世设达尔场织历花受求传口断况采精金界品判参层止边清至万确究书术状厂须离再目海交权且儿青才证低越际八试规斯近注办布门铁需走议县兵固除般引齿千胜细影济白格效置推空配刀叶率述今选养德话查差半敌始片施响收华觉备名红续均药标记难存测士身紧液派准斤角降维板许破述技消底床田势端感往神便贺村构照容非搞亚磨族火段算适讲按值美态黄易彪服早班麦削信排台声该击素张密害侯草何树肥继右属市严径螺检左页抗苏显苦英快称坏移约巴材省黑武培著河帝仅针怎植京助升王眼她抓含苗副杂普谈围食射源例致酸旧却充足短划剂宣环落首尺波承粉践府鱼随考刻靠够满夫失包住促枝局菌杆周护岩师举曲春元超负砂封换太模贫减阳扬江析亩木言球朝医校古呢稻宋听唯输滑站另卫字鼓刚写刘微略范供阿块某功套友限项余倒卷创律雨让骨远帮初皮播优占死毒圈伟季训控激找叫云互跟裂粮粒母练塞钢顶策双留误础吸阻故寸盾晚丝女散焊功株亲院冷彻弹错散商视艺灭版烈零室轻血倍缺厘泵察绝富城冲喷壤简否柱李望盘磁雄似困巩益洲脱投送奴侧润盖挥距触星松送获兴独官混纪依未突架宽冬章湿偏纹吃执阀矿寨责熟稳夺硬价努翻奇甲预职评读背协损棉侵灰虽矛厚罗泥辟告卵箱掌氧恩爱停曾溶营终纲孟钱待尽俄缩沙退陈讨奋械载胞幼哪剥迫旋征槽倒握担仍呀鲜吧卡粗介钻逐弱脚怕盐末阴丰编印蜂急拿扩伤飞露核缘游振操央伍域甚迅辉异序免纸夜乡久隶缸夹念兰映沟乙吗儒杀汽磷艰晶插埃燃欢铁补咱芽永瓦倾阵碳演威附牙芽永瓦斜灌欧献顺猪洋腐请透司危括脉宜笑若尾束壮暴企菜穗楚汉愈绿拖牛份染既秋遍锻玉夏疗尖殖井费州访吹荣铜沿替滚客召旱悟刺脑措贯藏敢令隙炉壳硫煤迎铸粘探临薄旬善福纵择礼愿伏残雷延烟句纯渐耕跑泽慢栽鲁赤繁境潮横掉锥希池败船假亮谓托伙哲怀割摆贡呈劲财仪沉炼麻罪祖息车穿货销齐鼠抽画饲龙库守筑房歌寒喜哥洗蚀废纳腹乎录镜妇恶脂庄擦险赞钟摇典柄辩竹谷卖乱虚桥奥伯赶垂途额壁网截野遗静谋弄挂课镇妄盛耐援扎虑键归符庆聚绕摩忙舞遇索顾胶羊湖钉仁音迹碎伸灯避泛亡答勇频皇柳哈揭甘诺概宪浓岛袭谁洪谢炮浇斑讯懂灵蛋闭孩释乳巨徒私银伊景坦累匀霉杜乐勒隔弯绩招绍胡呼痛峰零柴簧午跳居尚丁秦稍追梁折耗碱殊岗挖氏刃剧堆赫荷胸衡勤膜篇登驻案刊秧缓凸役剪川雪链渔啦脸户洛孢勃盟买杨宗焦赛旗滤硅炭股坐蒸凝竟陷枪黎救冒暗洞犯筒您宋弧爆谬涂味津臂障褐陆啊健尊豆拔莫抵桑坡缝警挑污冰柬嘴啥饭塑寄赵喊垫康遵牧遭幅园腔订香肉弟屋敏恢忘衣孙龄岭骗休借丹渡耳刨虎笔稀昆浪萨茶滴浅拥穴覆伦娘吨浸袖珠雌妈紫戏塔锤震岁貌洁剖牢锋疑霸闪埔猛诉刷狠忽灾闹乔唐漏闻沈熔氯荒茎男凡抢像浆旁玻亦忠唱蒙予纷捕锁尤乘乌智淡允叛畜俘摸锈扫毕璃宝芯爷鉴秘净蒋钙肩腾枯抛轨堂拌爸循诱祝励肯酒绳穷塘燥泡袋朗喂铝软渠颗惯贸粪综墙趋彼届墨碍启逆卸航雾冠丙街莱贝辐肠付吉渗瑞惊顿挤秒悬姆烂森糖圣凹陶词迟蚕亿矩";
        $dictlen = mb_strlen($dict, 'UTF-8');
        $image = $this->image;
        $fontfile = $this->sourcedir . $this->fonts[array_rand($this->fonts) ];
        $color = imagecolorallocate($image, 0, 0, 0);
        $verify = '';
        for ($i = 0;$i < $n;$i++) {
            $verify.= $word = mb_substr($dict, mt_rand(0, $dictlen - 1) , 1, 'UTF-8');
            imagettftext($image, rand(18, 22) , rand(-20, 20) , 5 + $i * 25, 25, $color, $fontfile, $word);
        }
        $this->verify = $verify;
        return $this;
    }
    
    public function genFomula() {
        $symbols = array(
            '＋' => '+',
            '－' => '-',
            '×' => '*',
            '加' => '+',
            '减' => '-',
            '乘' => '*'
        );
        $numbers = array(
            '0' => 0,
            '1' => 1,
            '2' => 2,
            '3' => 3,
            '4' => 4,
            '5' => 5,
            '6' => 6,
            '7' => 7,
            '8' => 8,
            '9' => 9,
            '零' => 0,
            '四' => 4,
            '五' => 5,
            '六' => 6,
            '七' => 7,
            '八' => 8,
            '九' => 9,
            '壹' => 1,
            '贰' => 2,
            '叁' => 3,
            '肆' => 4,
            '伍' => 5,
            '陆' => 6,
            '柒' => 7,
            '捌' => 8,
            '玖' => 9,
        );
        $image = $this->image;
        $fontfile = $this->sourcedir . $this->fonts[array_rand($this->fonts) ];
        $numidx1 = array_rand($numbers);
        $num1 = $numbers[$numidx1];
        $symbol = array_rand($symbols);
        $color = imagecolorallocate($image, 0, 0, 0);
        while (1) {
            $numidx2 = array_rand($numbers);
            $num2 = $numbers[$numidx2];
            if ($symbols[$symbol] != '-' || $num2 <= $num1) { //减法结果不为负数
                break;
            }
        }
        eval("\$verify = " . "$num1" . $symbols[$symbol] . "$num2;");
        $verify = intval($verify);
        $codelist = array(
            $numidx1,
            $symbol,
            $numidx2,
            '='
        );
        foreach ($codelist as $i => $code) {
            imagettftext($image, mt_rand(14, 16) , mt_rand(-15, 15) , ($i * 18) + 3, mt_rand(20, 25) , $color, $fontfile, $code);
        }
        return $this;
    }
    
    /**
     * 动画
     */
    public function genCodeAnimate($n = 4, $flags = 40) {
        $dict = 'ABCDEFGHIJKLNMPQRSTUVWXYZ123456789';
        $dictlen = strlen($dict);
        $verify = '';
        $fontfile = $this->sourcedir . $this->fonts[0];
        $colors = array(
            imagecolorallocate($this->image, 255, 0, 0) , //红
            imagecolorallocate($this->image, 0, 0, 255) , //蓝
            imagecolorallocate($this->image, 0, 0, 0) , //黑
        );
        $fontColors = array();
        $fontSizes = array();
        $gifs = array();
        for ($i = 0;$i < $n;$i++) {
            $verify.= substr($dict, mt_rand(0, $dictlen - 1) , 1);
            $fontColors[$i] = $colors[array_rand($colors) ];
            $fontSizes[$i] = rand(18, 22);
        }
        for ($f = 0;$f < $flags;$f++) {
            $image = $this->imgClone($this->image);
            $angle = - 15 + abs($f - $flags / 2) * 2; //角度
            $y = 20 + abs($f - $flags / 2) * 0.5;
            for ($i = 0;$i < $n;$i++) {
                $code = substr($verify, $i, 1);
                imagettftext($image, $fontSizes[$i], $angle, ($i * 15) - 20 + abs($f - $flags / 2) * 5, $y, $fontColors[$i], $fontfile, $code);
            }
            header("Content-type: image/gif");
            imagegif($image);
            imagedestroy($image);
            $gifs[] = ob_get_contents();
            ob_clean();
        }
        ob_start();
        $gifEncoder = new GIFEncoder($gifs, 100, 0, 1, 0, 0, 1, 'bin');
        header('Content-type: image/gif');
        echo $gifEncoder->GetAnimation();
        return $verify;
    }
    
    public function flush() {
        header('Content-type: image/png');
        imagepng($this->image);
        imagedestroy($this->image);
        imagedestroy($this->backimg);
        return $this->verify;
    }
    
    /**
     * 扭曲
     */
    public function twist() {
        $distImage = imagecreatetruecolor($this->width, $this->height);
        imagecopy($distImage, $this->backimg, 0, 0, 0, 0, $this->width, $this->height);
        for ($x = 0;$x < $this->width;$x++) {
            for ($y = 0;$y < $this->height;$y++) {
                $rgb = imagecolorat($this->image, $x, $y);
                imagesetpixel($distImage, (int)($x + sin($y / $this->height * 2 * M_PI - M_PI * 0.1) * 4) , $y, $rgb);
            }
        }
        $this->image = $distImage;
        return $this;
    }
    
    /**
     * 加噪点
     */
    public function addNoise($n = 50) {
        $image = $this->image;
        $color = imagecolorallocate($image, 0, 0, 0);
        for ($i = 0;$i < $n;$i++) { //噪声点
            imagesetpixel($image, mt_rand(0, $this->width) , mt_rand(0, $this->height) , $color);
        }
        return $this;
    }
    
    /**
     * 加噪音线
     */
    public function addLine($n = 1) {
        $image = $this->image;
        $color = imagecolorallocate($image, 0, 0, 0);
        for ($i = 0;$i < $n;$i++) {
            imagearc($image, rand(-10, $this->width + 10) , rand(-10, 0) , rand($this->width * 2 + 10, $this->width * 2 + 40) , rand($this->height, $this->height + 20) , 0, 360, $color);
        }
        return $this;
    }
    
    public function imgClone($image) {
        $copy = imagecreatetruecolor($this->width, $this->height);
        imagecopy($copy, $image, 0, 0, 0, 0, $this->width, $this->height);
        return $copy;
    }
    
}

Class GIFEncoder {
    
    var $GIF = "GIF89a"; /* GIF header 6 bytes        */
    var $VER = "GIFEncoder V2.06"; /* Encoder version                */
    var $BUF = Array();
    var $LOP = 0;
    var $DIS = 2;
    var $COL = - 1;
    var $IMG = - 1;
    var $ERR = Array(
        'ERR00' => "Does not supported function for only one image!",
        'ERR01' => "Source is not a GIF image!",
        'ERR02' => "Unintelligible flag ",
        'ERR03' => "Could not make animation from animated GIF source",
    );
    
    /*
      :::::::::::::::::::::::::::::::::::::::::::::::::::
      ::
      ::        GIFEncoder...
      ::
    */
    
    function GIFEncoder($GIF_src, $GIF_dly, $GIF_lop, $GIF_dis, $GIF_red, $GIF_grn, $GIF_blu, $GIF_mod) {
        if (!is_array($GIF_src) && !is_array($GIF_tim)) {
            printf("%s: %s", $this->VER, $this->ERR['ERR00']);
            exit(0);
        }
        $this->LOP = ($GIF_lop > - 1) ? $GIF_lop : 0;
        $this->DIS = ($GIF_dis > - 1) ? (($GIF_dis < 3) ? $GIF_dis : 3) : 2;
        $this->COL = ($GIF_red > - 1 && $GIF_grn > - 1 && $GIF_blu > - 1) ? ($GIF_red | ($GIF_grn << 8) | ($GIF_blu << 16)) : -1;
        
        for ($i = 0;$i < count($GIF_src);$i++) {
            if (strToLower($GIF_mod) == "url") {
                $this->BUF[] = fread(fopen($GIF_src[$i], "rb") , filesize($GIF_src[$i]));
            } else if (strToLower($GIF_mod) == "bin") {
                $this->BUF[] = $GIF_src[$i];
            } else {
                printf("%s: %s ( %s )!", $this->VER, $this->ERR['ERR02'], $GIF_mod);
                exit(0);
            }
            if (substr($this->BUF[$i], 0, 6) != "GIF87a" && substr($this->BUF[$i], 0, 6) != "GIF89a") {
                printf("%s: %d %s", $this->VER, $i, $this->ERR['ERR01']);
                exit(0);
            }
            for ($j = (13 + 3 * (2 << (ord($this->BUF[$i] {
                10
            }) & 0x07))) , $k = TRUE;$k;$j++) {
                switch ($this->BUF[$i] {
                        $j
                }) {
                    case "!":
                        if ((substr($this->BUF[$i], ($j + 3) , 8)) == "NETSCAPE") {
                            printf("%s: %s ( %s source )!", $this->VER, $this->ERR['ERR03'], ($i + 1));
                            exit(0);
                        }
                    break;
                    case ";":
                        $k = FALSE;
                    break;
                }
            }
        }
        GIFEncoder::GIFAddHeader();
        for ($i = 0;$i < count($this->BUF);$i++) {
            GIFEncoder::GIFAddFrames($i, $GIF_dly[$i]);
        }
        GIFEncoder::GIFAddFooter();
    }
    
    /*
      :::::::::::::::::::::::::::::::::::::::::::::::::::
      ::
      ::        GIFAddHeader...
      ::
    */
    
    function GIFAddHeader() {
        $cmap = 0;
        
        if (ord($this->BUF[0] {
            10
        }) & 0x80) {
            $cmap = 3 * (2 << (ord($this->BUF[0] {
                10
            }) & 0x07));
            
            $this->GIF.= substr($this->BUF[0], 6, 7);
            $this->GIF.= substr($this->BUF[0], 13, $cmap);
            $this->GIF.= "!\377\13NETSCAPE2.0\3\1" . GIFEncoder::GIFWord($this->LOP) . "\0";
        }
    }
    
    /*
      :::::::::::::::::::::::::::::::::::::::::::::::::::
      ::
      ::        GIFAddFrames...
      ::
    */
    
    function GIFAddFrames($i, $d) {
        
        $Locals_str = 13 + 3 * (2 << (ord($this->BUF[$i] {
            10
        }) & 0x07));
        
        $Locals_end = strlen($this->BUF[$i]) - $Locals_str - 1;
        $Locals_tmp = substr($this->BUF[$i], $Locals_str, $Locals_end);
        
        $Global_len = 2 << (ord($this->BUF[0] {
            10
        }) & 0x07);
        $Locals_len = 2 << (ord($this->BUF[$i] {
            10
        }) & 0x07);
        
        $Global_rgb = substr($this->BUF[0], 13, 3 * (2 << (ord($this->BUF[0] {
            10
        }) & 0x07)));
        $Locals_rgb = substr($this->BUF[$i], 13, 3 * (2 << (ord($this->BUF[$i] {
            10
        }) & 0x07)));
        
        $Locals_ext = "!\xF9\x04" . chr(($this->DIS << 2) + 0) . chr(($d >> 0) & 0xFF) . chr(($d >> 8) & 0xFF) . "\x0\x0";
        
        if ($this->COL > - 1 && ord($this->BUF[$i] {
            10
        }) & 0x80) {
            for ($j = 0;$j < (2 << (ord($this->BUF[$i] {
                10
            }) & 0x07));$j++) {
                if (ord($Locals_rgb{3 * $j + 0}) == ($this->COL >> 0) & 0xFF && ord($Locals_rgb{3 * $j + 1}) == ($this->COL >> 8) & 0xFF && ord($Locals_rgb{3 * $j + 2}) == ($this->COL >> 16) & 0xFF) {
                    $Locals_ext = "!\xF9\x04" . chr(($this->DIS << 2) + 1) . chr(($d >> 0) & 0xFF) . chr(($d >> 8) & 0xFF) . chr($j) . "\x0";
                    break;
                }
            }
        }
        switch ($Locals_tmp{0}) {
            case "!":
                $Locals_img = substr($Locals_tmp, 8, 10);
                $Locals_tmp = substr($Locals_tmp, 18, strlen($Locals_tmp) - 18);
            break;
            case ",":
                $Locals_img = substr($Locals_tmp, 0, 10);
                $Locals_tmp = substr($Locals_tmp, 10, strlen($Locals_tmp) - 10);
            break;
        }
        if (ord($this->BUF[$i] {
            10
        }) & 0x80 && $this->IMG > - 1) {
            if ($Global_len == $Locals_len) {
                if (GIFEncoder::GIFBlockCompare($Global_rgb, $Locals_rgb, $Global_len)) {
                    $this->GIF.= ($Locals_ext . $Locals_img . $Locals_tmp);
                } else {
                    $byte = ord($Locals_img{9});
                    $byte|= 0x80;
                    $byte&= 0xF8;
                    $byte|= (ord($this->BUF[0] {
                        10
                    }) & 0x07);
                    $Locals_img{9} = chr($byte);
                    $this->GIF.= ($Locals_ext . $Locals_img . $Locals_rgb . $Locals_tmp);
                }
            } else {
                $byte = ord($Locals_img{9});
                $byte|= 0x80;
                $byte&= 0xF8;
                $byte|= (ord($this->BUF[$i] {
                    10
                }) & 0x07);
                $Locals_img{9} = chr($byte);
                $this->GIF.= ($Locals_ext . $Locals_img . $Locals_rgb . $Locals_tmp);
            }
        } else {
            $this->GIF.= ($Locals_ext . $Locals_img . $Locals_tmp);
        }
        $this->IMG = 1;
    }
    
    /*
      :::::::::::::::::::::::::::::::::::::::::::::::::::
      ::
      ::        GIFAddFooter...
      ::
    */
    
    function GIFAddFooter() {
        $this->GIF.= ";";
    }
    
    /*
      :::::::::::::::::::::::::::::::::::::::::::::::::::
      ::
      ::        GIFBlockCompare...
      ::
    */
    
    function GIFBlockCompare($GlobalBlock, $LocalBlock, $Len) {
        
        for ($i = 0;$i < $Len;$i++) {
            if ($GlobalBlock{3 * $i + 0} != $LocalBlock{3 * $i + 0} || $GlobalBlock{3 * $i + 1} != $LocalBlock{3 * $i + 1} || $GlobalBlock{3 * $i + 2} != $LocalBlock{3 * $i + 2}) {
                return (0);
            }
        }
        
        return (1);
    }
    
    /*
      :::::::::::::::::::::::::::::::::::::::::::::::::::
      ::
      ::        GIFWord...
      ::
    */
    
    function GIFWord($int) {
        
        return (chr($int & 0xFF) . chr(($int >> 8) & 0xFF));
    }
    
    /*
      :::::::::::::::::::::::::::::::::::::::::::::::::::
      ::
      ::        GetAnimation...
      ::
    */
    
    function GetAnimation() {
        return ($this->GIF);
    }
    
}
$vp = new VerifyPic(70, 30);
$vp->genCode()->twist()->flush();
